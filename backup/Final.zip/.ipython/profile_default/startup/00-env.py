# *WARNING* Do not change this file as it may break your notebooks

import os
os.environ['HOME'] = '/home/adminkhatadashboard'
os.environ['LC_CTYPE'] = 'en_US.utf-8'
os.environ['JAVA_HOME'] = '/usr/lib/jvm/default-java'
os.environ['TERM'] = 'xterm-256color'
os.environ['PYTHONSTARTUP'] = '/home/adminkhatadashboard/.pythonstartup.py'
os.environ['PYTHONANYWHERE_DOMAIN'] = 'pythonanywhere.com'
os.environ['PYTHONANYWHERE_SITE'] = 'www.pythonanywhere.com'
os.environ['http_proxy'] = 'http://proxy.server:3128'
os.environ['https_proxy'] = 'http://proxy.server:3128'
os.environ['no_proxy'] = 'localhost,127.0.0.1,localaddress,.localdomain.com,/var/run/docker.sock'
